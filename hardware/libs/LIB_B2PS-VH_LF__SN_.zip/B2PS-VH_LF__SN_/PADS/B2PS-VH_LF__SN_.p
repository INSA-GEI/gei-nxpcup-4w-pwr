*PADS-LIBRARY-PART-TYPES-V9*

B2PS-VH_LF__SN_ B2PSVHLFSN I CON 7 1 0 0 0
TIMESTAMP 2026.05.26.13.11.27
"Mouser Part Number" N/A
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/JST-Commercial/B2PS-VHLFSN?qs=QpmGXVUTftGp5gBbBqL80A%3D%3D
"Manufacturer_Name" JST (JAPAN SOLDERLESS TERMINALS)
"Manufacturer_Part_Number" B2PS-VH(LF)(SN)
"Description" WIRE-BOARD CONNECTOR, HEADER 2 POSITION 3.96MM; Connector Systems:Wire-to-Board; Pitch Spacing:3.96mm; No. of Rows:1Rows; No. of Contacts:2Contacts; Contact Termination Type:Through Hole; Product Range:VH Series; Gender:Header RoHS Compliant: Yes
"Datasheet Link" https://g.componentsearchengine.com/ga/Z3usPug12#
"Geometry.Height" 8.5mm
GATE 1 2 0
B2PS-VH_LF__SN_
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
12866729/8023/2.50/2/3/Connector
