/**
 * @file    i2c_slave_driver.h
 * @brief   Driver esclave I2C (LPI2C0) pour NXP MCXA153
 *
 * Bus : LPI2C0, SCL=P1.9, SDA=P1.8
 * Adresse esclave : 0x42
 * Vitesse : 100 kHz
 * Horloge LPI2C0 : 24 MHz, SYSTEM : 96 MHz
 *
 * Standard : GNU C17 (GCC)
 * SDK       : FRDM_MCXA153 v3.15+
 */

#ifndef I2C_SLAVE_DRIVER_H
#define I2C_SLAVE_DRIVER_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>
#include "fsl_lpi2c.h"

/* =========================================================================
 * Adresses des registres
 * ========================================================================= */
#define REG_ADDR_ID        (0x00U)   /**< Identifiant carte (RO) - toujours 0xBEEF (2 octets) */
#define REG_ADDR_SR        (0x01U)   /**< Status register carte PWR (RO) */
#define REG_ADDR_VBAT_1R   (0x02U)   /**< VBAT poids faible (RO) */
#define REG_ADDR_VBAT_2R   (0x03U)   /**< VBAT poids fort (RO) */
#define REG_ADDR_ODO1_1R   (0x04U)   /**< Odométrie voie 1, octet 1 poids faible (RO) */
#define REG_ADDR_ODO1_2R   (0x05U)   /**< Odométrie voie 1, octet 2 (RO) */
#define REG_ADDR_ODO1_3R   (0x06U)   /**< Odométrie voie 1, octet 3 (RO) */
#define REG_ADDR_ODO1_4R   (0x07U)   /**< Odométrie voie 1, octet 4 poids fort (RO) */
#define REG_ADDR_ODO2_1R   (0x08U)   /**< Odométrie voie 2, octet 1 poids faible (RO) */
#define REG_ADDR_ODO2_2R   (0x09U)   /**< Odométrie voie 2, octet 2 (RO) */
#define REG_ADDR_ODO2_3R   (0x0AU)   /**< Odométrie voie 2, octet 3 (RO) */
#define REG_ADDR_ODO2_4R   (0x0BU)   /**< Odométrie voie 2, octet 4 poids fort (RO) */
#define REG_ADDR_MOT1_1R   (0x0CU)   /**< Commande moteur 1, poids faible (RW) */
#define REG_ADDR_MOT1_2R   (0x0DU)   /**< Commande moteur 1, poids fort (RW) */
#define REG_ADDR_MOT2_1R   (0x0EU)   /**< Commande moteur 2, poids faible (RW) */
#define REG_ADDR_MOT2_2R   (0x0FU)   /**< Commande moteur 2, poids fort (RW) */
#define REG_ADDR_DIR_1R    (0x10U)   /**< Commande direction, poids faible (RW) */
#define REG_ADDR_DIR_2R    (0x11U)   /**< Commande direction, poids fort (RW) */
#define REG_ADDR_CR        (0x12U)   /**< Registre de contrôle (RW) */
#define REG_COUNT          (0x13U)   /**< Nombre total de registres */

/* =========================================================================
 * Flag global levé lors d'une écriture maître sur registre(s) RW
 * ========================================================================= */
/**
 * @brief Flag levé par le driver dès qu'un maître I2C modifie au moins un
 *        registre RW. L'application doit le remettre à false après traitement.
 */
extern volatile bool gI2CChanged;

/* =========================================================================
 * Initialisation / arrêt
 * ========================================================================= */

/**
 * @brief  Initialise le périphérique LPI2C0 en mode esclave (interruptions).
 *         Configure les pins P1.8/P1.9, l'horloge et enregistre l'ISR.
 * @return kStatus_Success en cas de succès, code d'erreur SDK sinon.
 */
status_t I2CSlave_Init(void);

/**
 * @brief  Désactive le périphérique LPI2C0 et libère les ressources.
 */
void I2CSlave_Deinit(void);

/* =========================================================================
 * Getters — registres Read-Only (mis à jour par l'application)
 * ========================================================================= */

/**
 * @brief Retourne la valeur du registre ID (2 octets, toujours 0xBEEF).
 *        REG[0x00] = octet bas, REG[0x01] = (non utilisé, mais 0xBE conservé).
 */
uint8_t  I2CSlave_GetID_Low(void);
uint8_t  I2CSlave_GetID_High(void);

/** @brief Retourne le registre SR (status carte PWR). */
uint8_t  I2CSlave_GetSR(void);

/** @brief Met à jour le registre SR depuis l'application. */
void     I2CSlave_SetSR(uint8_t value);

/** @brief Retourne VBAT octet bas / fort. */
uint8_t  I2CSlave_GetVBAT_Low(void);
uint8_t  I2CSlave_GetVBAT_High(void);

/**
 * @brief Met à jour la mesure VBAT (16 bits, little-endian dans les registres).
 * @param vbat Valeur 16 bits de la tension batterie.
 */
void     I2CSlave_SetVBAT(uint16_t vbat);

/** @brief Retourne un octet (0..3) de la mesure odométrie voie 1. */
uint8_t  I2CSlave_GetODO1_Byte(uint8_t byteIndex);

/**
 * @brief Met à jour la mesure odométrie voie 1 (32 bits, little-endian).
 * @param odo Valeur 32 bits de l'odométrie.
 */
void     I2CSlave_SetODO1(uint32_t odo);

/** @brief Retourne un octet (0..3) de la mesure odométrie voie 2. */
uint8_t  I2CSlave_GetODO2_Byte(uint8_t byteIndex);

/**
 * @brief Met à jour la mesure odométrie voie 2 (32 bits, little-endian).
 * @param odo Valeur 32 bits de l'odométrie.
 */
void     I2CSlave_SetODO2(uint32_t odo);

/* =========================================================================
 * Getters / Setters — registres Read-Write (lus/écrits par le maître I2C
 * et consultés/modifiés par l'application)
 * ========================================================================= */

/** @brief Retourne la commande moteur 1 (16 bits, little-endian). */
uint16_t I2CSlave_GetMOT1(void);

/** @brief Surcharge la commande moteur 1 depuis l'application. */
void     I2CSlave_SetMOT1(uint16_t value);

/** @brief Retourne la commande moteur 2 (16 bits, little-endian). */
uint16_t I2CSlave_GetMOT2(void);

/** @brief Surcharge la commande moteur 2 depuis l'application. */
void     I2CSlave_SetMOT2(uint16_t value);

/** @brief Retourne la commande direction (16 bits, little-endian). */
uint16_t I2CSlave_GetDIR(void);

/** @brief Surcharge la commande direction depuis l'application. */
void     I2CSlave_SetDIR(uint16_t value);

/** @brief Retourne le registre de contrôle CR. */
uint8_t  I2CSlave_GetCR(void);

/** @brief Surcharge le registre CR depuis l'application. */
void     I2CSlave_SetCR(uint8_t value);

#ifdef __cplusplus
}
#endif

#endif /* I2C_SLAVE_DRIVER_H */
