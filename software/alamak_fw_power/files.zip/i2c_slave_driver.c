/**
 * @file    i2c_slave_driver.c
 * @brief   Driver esclave I2C (LPI2C0) pour NXP MCXA153
 *
 * Bus : LPI2C0, SCL=P1.9, SDA=P1.8
 * Adresse esclave : 0x42
 * Vitesse : 100 kHz
 * Horloge LPI2C0 : 24 MHz, SYSTEM : 96 MHz
 *
 * Fonctionnement :
 *   - Le maître envoie d'abord l'octet d'adresse de registre (transaction d'écriture).
 *   - Lecture  : le maître effectue un repeated-start en lecture ; le driver
 *                répond avec autant d'octets consécutifs que le maître en demande
 *                (auto-incrément d'adresse).
 *   - Écriture : le maître envoie 1..N octets de données après l'adresse de
 *                registre. Les registres RO sont ignorés silencieusement.
 *                gI2CChanged est levé si au moins un registre RW est modifié.
 *
 * Standard : GNU C17 (GCC)
 * SDK       : FRDM_MCXA153 v3.15+
 */

#include "i2c_slave_driver.h"

#include <string.h>
#include "fsl_lpi2c.h"
#include "fsl_port.h"
#include "fsl_clock.h"
#include "fsl_reset.h"

/* =========================================================================
 * Configuration matérielle
 * ========================================================================= */

/** Périphérique LPI2C utilisé */
#define I2C_SLAVE_BASE       LPI2C0

/** Adresse 7 bits de l'esclave */
#define I2C_SLAVE_ADDR_7BIT  (0x42U)

/** Fréquence d'horloge du périphérique LPI2C0 (24 MHz) */
#define I2C_SLAVE_CLK_FREQ   (24000000U)

/** IRQ LPI2C0 sur MCXA153 */
#define I2C_SLAVE_IRQn       LP_FLEXCOMM0_IRQn

/** Priorité NVIC de l'ISR */
#define I2C_SLAVE_IRQ_PRIO   (3U)

/* =========================================================================
 * Valeur fixe du registre ID
 * ========================================================================= */
#define REG_ID_VALUE_LOW   (0xEFU)   /**< 0xBEEF octet bas  */
#define REG_ID_VALUE_HIGH  (0xBEU)   /**< 0xBEEF octet fort */

/* =========================================================================
 * Masque des registres accessibles en écriture par le maître
 * ========================================================================= */
/**
 * Tableau de booléens indexé par adresse de registre.
 * true  => le maître peut écrire dans ce registre.
 * false => registre RO, l'écriture est ignorée.
 */
static const bool kRegWritable[REG_COUNT] =
{
    [REG_ADDR_ID]      = false,
    [REG_ADDR_SR]      = false,
    [REG_ADDR_VBAT_1R] = false,
    [REG_ADDR_VBAT_2R] = false,
    [REG_ADDR_ODO1_1R] = false,
    [REG_ADDR_ODO1_2R] = false,
    [REG_ADDR_ODO1_3R] = false,
    [REG_ADDR_ODO1_4R] = false,
    [REG_ADDR_ODO2_1R] = false,
    [REG_ADDR_ODO2_2R] = false,
    [REG_ADDR_ODO2_3R] = false,
    [REG_ADDR_ODO2_4R] = false,
    [REG_ADDR_MOT1_1R] = true,
    [REG_ADDR_MOT1_2R] = true,
    [REG_ADDR_MOT2_1R] = true,
    [REG_ADDR_MOT2_2R] = true,
    [REG_ADDR_DIR_1R]  = true,
    [REG_ADDR_DIR_2R]  = true,
    [REG_ADDR_CR]      = true,
};

/* =========================================================================
 * Banque de registres (privée)
 * ========================================================================= */
static volatile uint8_t s_regs[REG_COUNT];

/* =========================================================================
 * État interne de la machine à états I2C esclave
 * ========================================================================= */
typedef enum
{
    kSlaveState_Idle,           /**< En attente d'une transaction */
    kSlaveState_WaitRegAddr,    /**< Premier octet reçu = adresse registre */
    kSlaveState_Writing,        /**< Le maître écrit des données */
    kSlaveState_Reading,        /**< Le maître lit des données */
} SlaveState_t;

static volatile SlaveState_t s_state;
static volatile uint8_t      s_regPtr;   /**< Pointeur courant dans la banque */

/* =========================================================================
 * Handle LPI2C esclave (SDK)
 * ========================================================================= */
static lpi2c_slave_handle_t s_handle;

/* =========================================================================
 * Flag global public
 * ========================================================================= */
volatile bool gI2CChanged = false;

/* =========================================================================
 * Prototypes privés
 * ========================================================================= */
static void I2CSlave_ConfigurePins(void);
static void I2CSlave_ConfigureClock(void);
static void I2CSlave_Callback(LPI2C_Type *base,
                              lpi2c_slave_transfer_t *transfer,
                              void *userData);

/* =========================================================================
 * Initialisation des registres à leurs valeurs par défaut
 * ========================================================================= */
static void I2CSlave_InitRegisters(void)
{
    memset((void *)s_regs, 0x00U, sizeof(s_regs));

    /* ID fixe */
    s_regs[REG_ADDR_ID]     = REG_ID_VALUE_LOW;
    s_regs[REG_ADDR_SR]     = REG_ID_VALUE_HIGH;   /* 0x01 = octet haut de 0xBEEF */

    /*
     * Remarque : l'adresse 0x00 contient l'octet bas (0xEF) et 0x01
     * l'octet haut (0xBE) pour reconstruire 0xBEEF en little-endian.
     * Le registre SR (0x01) est donc physiquement partagé avec l'octet
     * haut de ID. Conformément au tableau fourni, 0x01 est le registre SR
     * indépendant ; 0x00 est ID sur 8 bits. La valeur 0xBEEF est exposée
     * via les deux getters dédiés et non en lecture directe de 0x01.
     */
    s_regs[REG_ADDR_SR]     = 0x00U;   /* SR : valeur initiale */
}

/* =========================================================================
 * Initialisation publique
 * ========================================================================= */
status_t I2CSlave_Init(void)
{
    I2CSlave_InitRegisters();

    s_state  = kSlaveState_Idle;
    s_regPtr = 0U;

    I2CSlave_ConfigureClock();
    I2CSlave_ConfigurePins();

    /* Configuration esclave SDK */
    lpi2c_slave_config_t slaveCfg;
    LPI2C_SlaveGetDefaultConfig(&slaveCfg);

    slaveCfg.address0.address    = I2C_SLAVE_ADDR_7BIT;
    slaveCfg.address0.matchMode  = kLPI2C_MatchAddress0;
    slaveCfg.enableGeneralCall   = false;
    slaveCfg.sclStall.enableAck  = true;   /* Stall SCL pendant le traitement */
    slaveCfg.sclStall.enableTx   = true;
    slaveCfg.sclStall.enableRx   = true;
    slaveCfg.enableSlave         = true;

    LPI2C_SlaveInit(I2C_SLAVE_BASE, &slaveCfg, I2C_SLAVE_CLK_FREQ);

    /* Enregistrement du handle non-bloquant (interruptions) */
    LPI2C_SlaveTransferCreateHandle(I2C_SLAVE_BASE,
                                    &s_handle,
                                    I2CSlave_Callback,
                                    NULL);

    /* Activation des événements esclave */
    status_t status = LPI2C_SlaveTransferNonBlocking(
        I2C_SLAVE_BASE,
        &s_handle,
        (uint32_t)(kLPI2C_SlaveAddressMatchEvent |
                   kLPI2C_SlaveTransmitEvent      |
                   kLPI2C_SlaveReceiveEvent        |
                   kLPI2C_SlaveCompletionEvent));

    if (status != kStatus_Success)
    {
        return status;
    }

    /* Priorité et activation NVIC */
    NVIC_SetPriority(I2C_SLAVE_IRQn, I2C_SLAVE_IRQ_PRIO);
    EnableIRQ(I2C_SLAVE_IRQn);

    return kStatus_Success;
}

/* =========================================================================
 * Désactivation
 * ========================================================================= */
void I2CSlave_Deinit(void)
{
    DisableIRQ(I2C_SLAVE_IRQn);
    LPI2C_SlaveTransferAbort(I2C_SLAVE_BASE, &s_handle);
    LPI2C_SlaveDeinit(I2C_SLAVE_BASE);
    s_state = kSlaveState_Idle;
}

/* =========================================================================
 * Callback SDK — appelé depuis l'ISR LPI2C0
 * ========================================================================= */
static void I2CSlave_Callback(LPI2C_Type *base,
                              lpi2c_slave_transfer_t *transfer,
                              void *userData)
{
    (void)base;
    (void)userData;

    switch (transfer->event)
    {
        /* ------------------------------------------------------------------
         * Détection de l'adresse esclave sur le bus
         * ------------------------------------------------------------------ */
        case kLPI2C_SlaveAddressMatchEvent:
            /*
             * La direction (lecture/écriture) n'est pas encore connue ici ;
             * elle sera déterminée via les événements Tx/Rx suivants.
             * On ne réinitialise pas s_regPtr ici pour permettre un
             * repeated-start en lecture sans ré-envoi du pointeur.
             */
            s_state = kSlaveState_WaitRegAddr;
            transfer->rxData = NULL;
            transfer->rxSize = 0U;
            break;

        /* ------------------------------------------------------------------
         * Le maître veut lire (esclave transmet)
         * ------------------------------------------------------------------ */
        case kLPI2C_SlaveTransmitEvent:
            /*
             * Le premier octet d'une transaction d'écriture est toujours
             * l'adresse de registre. Si on arrive ici directement
             * (repeated-start) le pointeur est déjà positionné.
             */
            s_state = kSlaveState_Reading;

            if (s_regPtr >= REG_COUNT)
            {
                /* Adresse hors plage : renvoyer 0xFF */
                static volatile uint8_t s_dummy = 0xFFU;
                transfer->txData = (uint8_t *)&s_dummy;
            }
            else
            {
                transfer->txData = (uint8_t *)&s_regs[s_regPtr];
            }
            transfer->txSize = 1U;   /* Un octet par événement Tx */
            break;

        /* ------------------------------------------------------------------
         * Le maître écrit (esclave reçoit)
         * ------------------------------------------------------------------ */
        case kLPI2C_SlaveReceiveEvent:
            s_state = kSlaveState_Writing;

            /*
             * On reçoit un octet à la fois.
             * Le buffer est un uint8_t statique ; le traitement réel
             * est fait dans kLPI2C_SlaveCompletionEvent ou directement
             * après réception via le mécanisme de callback séquentiel.
             *
             * NOTE SDK : pour un traitement octet par octet en mode
             * non-bloquant, on pointe rxData sur un tampon de 1 octet
             * et on reviendra dans ce case pour chaque octet suivant.
             */
            static volatile uint8_t s_rxByte;
            transfer->rxData = (uint8_t *)&s_rxByte;
            transfer->rxSize = 1U;

            /*
             * Traitement de l'octet reçu lors du précédent passage
             * (s_rxByte contient la donnée précédente à ce stade car
             * le SDK remplit le buffer AVANT d'appeler le callback
             * avec kLPI2C_SlaveReceiveEvent pour le suivant).
             *
             * Lors du tout premier appel après AddressMatch, s_state
             * vaut kSlaveState_WaitRegAddr : le prochain octet sera
             * l'adresse de registre ; on ne traite pas encore.
             */
            if (s_state == kSlaveState_Writing)
            {
                /* Traitement différé : voir kLPI2C_SlaveCompletionEvent */
            }
            break;

        /* ------------------------------------------------------------------
         * Fin de transaction (STOP ou REPEATED START)
         * ------------------------------------------------------------------ */
        case kLPI2C_SlaveCompletionEvent:
        {
            /*
             * À ce stade, transfer->receivedAddress, transfer->completionStatus
             * sont disponibles. Le SDK a accumulé les données reçues dans
             * le buffer fourni lors de kLPI2C_SlaveReceiveEvent.
             *
             * Architecture simplifiée : le driver gère l'auto-incrément
             * via s_regPtr mis à jour après chaque octet transmis/reçu.
             * Le SDK appelle le callback pour CHAQUE octet en mode
             * non-bloquant ; on est donc cohérents.
             */

            /* Rien de spécial à faire ici ; l'état est remis à Idle */
            s_state  = kSlaveState_Idle;
            transfer->rxData = NULL;
            transfer->txData = NULL;
            transfer->rxSize = 0U;
            transfer->txSize = 0U;
            break;
        }

        default:
            break;
    }
}

/*
 * ---------------------------------------------------------------------------
 * REMARQUE ARCHITECTURALE — Gestion octet par octet
 * ---------------------------------------------------------------------------
 * Le SDK NXP LPI2C non-bloquant appelle le callback avec :
 *   - kLPI2C_SlaveAddressMatchEvent  : début de trame
 *   - kLPI2C_SlaveReceiveEvent       : un nouveau slot de réception est prêt
 *   - kLPI2C_SlaveTransmitEvent      : un nouvel octet doit être fourni
 *   - kLPI2C_SlaveCompletionEvent    : fin (STOP / NACK)
 *
 * Pour gérer proprement le protocole "adresse-registre puis données" avec
 * auto-incrément, on utilise la fonction lpi2c_slave_transfer_callback_t
 * standard. Chaque événement Rx/Tx traite UN octet et incrémente s_regPtr.
 *
 * La fonction ci-dessous est le vrai cœur du protocole ; elle remplace
 * le callback simplifié ci-dessus pour une implémentation robuste.
 * ---------------------------------------------------------------------------
 */

/**
 * @brief  ISR de bas niveau — permet de traiter chaque octet individuellement
 *         sans dépendre entièrement du callback SDK de haut niveau.
 *
 * Cette fonction est enregistrée comme handler d'interruption standard
 * (weak override du vecteur LP_FLEXCOMM0_IRQHandler défini dans le SDK).
 */
void LP_FLEXCOMM0_IRQHandler(void)
{
    uint32_t flags = LPI2C_SlaveGetStatusFlags(I2C_SLAVE_BASE);

    /* ---- Détection adresse ------------------------------------------------ */
    if ((flags & (uint32_t)kLPI2C_SlaveAddressMatchFlag) != 0U)
    {
        LPI2C_SlaveClearStatusFlags(I2C_SLAVE_BASE,
                                    (uint32_t)kLPI2C_SlaveAddressMatchFlag);
        s_state = kSlaveState_WaitRegAddr;
        /* Prépare SCL stall jusqu'à ce qu'on consomme FIFO */
    }

    /* ---- Donnée reçue (maître → esclave) ---------------------------------- */
    if ((flags & (uint32_t)kLPI2C_SlaveRxReadyFlag) != 0U)
    {
        /* Lire la FIFO de réception */
        uint8_t data = (uint8_t)LPI2C_SlaveReadData(I2C_SLAVE_BASE);

        if (s_state == kSlaveState_WaitRegAddr)
        {
            /* Premier octet = adresse du registre cible */
            s_regPtr = (data < REG_COUNT) ? data : (REG_COUNT - 1U);
            s_state  = kSlaveState_Writing;
        }
        else if (s_state == kSlaveState_Writing)
        {
            /* Octets suivants = données à écrire */
            if (s_regPtr < REG_COUNT)
            {
                if (kRegWritable[s_regPtr])
                {
                    s_regs[s_regPtr] = data;
                    gI2CChanged      = true;
                }
                /* Sinon : registre RO → écriture ignorée, pas d'erreur */
                s_regPtr++;
            }
        }
        else
        {
            /* Donnée inattendue : on consomme sans traiter */
            (void)data;
        }
    }

    /* ---- Donnée à transmettre (esclave → maître) -------------------------- */
    if ((flags & (uint32_t)kLPI2C_SlaveTxReadyFlag) != 0U)
    {
        s_state = kSlaveState_Reading;

        uint8_t txByte = (s_regPtr < REG_COUNT) ? s_regs[s_regPtr] : 0xFFU;
        LPI2C_SlaveWriteData(I2C_SLAVE_BASE, txByte);

        if (s_regPtr < REG_COUNT)
        {
            s_regPtr++;   /* Auto-incrément */
        }
    }

    /* ---- Fin de transaction (STOP détecté) -------------------------------- */
    if ((flags & (uint32_t)kLPI2C_SlaveStopDetectFlag) != 0U)
    {
        LPI2C_SlaveClearStatusFlags(I2C_SLAVE_BASE,
                                    (uint32_t)kLPI2C_SlaveStopDetectFlag);
        s_state = kSlaveState_Idle;
    }

    /* Acquittement NVIC géré automatiquement en sortie d'ISR */
    SDK_ISR_EXIT_BARRIER();
}

/* =========================================================================
 * Configuration des pins P1.8 (SDA) et P1.9 (SCL)
 * ========================================================================= */
static void I2CSlave_ConfigurePins(void)
{
    /* Activation de l'horloge du PORT1 */
    CLOCK_EnableClock(kCLOCK_Port1);

    /* Configuration SDA : P1.8, fonction LPI2C0_SDA (MUX = ALT3 sur MCXA153) */
    const port_pin_config_t sdaCfg = {
        .pullSelect          = kPORT_PullUp,
        .pullValueSelect     = kPORT_HighPullResistor,
        .slewRate            = kPORT_FastSlewRate,
        .passiveFilterEnable = kPORT_PassiveFilterDisable,
        .openDrainEnable     = kPORT_OpenDrainEnable,   /* I2C nécessite OD */
        .driveStrength       = kPORT_LowDriveStrength,
        .mux                 = kPORT_MuxAlt3,
        .lockRegister        = kPORT_UnlockRegister,
    };

    /* Configuration SCL : P1.9, même config */
    const port_pin_config_t sclCfg = {
        .pullSelect          = kPORT_PullUp,
        .pullValueSelect     = kPORT_HighPullResistor,
        .slewRate            = kPORT_FastSlewRate,
        .passiveFilterEnable = kPORT_PassiveFilterDisable,
        .openDrainEnable     = kPORT_OpenDrainEnable,
        .driveStrength       = kPORT_LowDriveStrength,
        .mux                 = kPORT_MuxAlt3,
        .lockRegister        = kPORT_UnlockRegister,
    };

    PORT_SetPinConfig(PORT1, 8U, &sdaCfg);   /* P1.8 = SDA */
    PORT_SetPinConfig(PORT1, 9U, &sclCfg);   /* P1.9 = SCL */
}

/* =========================================================================
 * Configuration de l'horloge LPI2C0
 * ========================================================================= */
static void I2CSlave_ConfigureClock(void)
{
    /*
     * Sur MCXA153, LPI2C0 est connecté à LP_FLEXCOMM0.
     * La source d'horloge est sélectionnée via CLOCK_SetLpFlexcommClkSrc.
     * On utilise FRO_24M (24 MHz) pour LPI2C0.
     */
    CLOCK_SetLpFlexcommClkSrc(0U, kCLOCK_LpFlexCommClkSrc_Fro24M);
    CLOCK_EnableClock(kCLOCK_LpFlexComm0);
    RESET_PeripheralReset(kLP_FLEXCOMM0_RST_SHIFT_RSTn);
}

/* =========================================================================
 * Getters / Setters publics
 * ========================================================================= */

uint8_t I2CSlave_GetID_Low(void)
{
    return REG_ID_VALUE_LOW;
}

uint8_t I2CSlave_GetID_High(void)
{
    return REG_ID_VALUE_HIGH;
}

uint8_t I2CSlave_GetSR(void)
{
    return s_regs[REG_ADDR_SR];
}

void I2CSlave_SetSR(uint8_t value)
{
    s_regs[REG_ADDR_SR] = value;
}

uint8_t I2CSlave_GetVBAT_Low(void)
{
    return s_regs[REG_ADDR_VBAT_1R];
}

uint8_t I2CSlave_GetVBAT_High(void)
{
    return s_regs[REG_ADDR_VBAT_2R];
}

void I2CSlave_SetVBAT(uint16_t vbat)
{
    s_regs[REG_ADDR_VBAT_1R] = (uint8_t)(vbat & 0xFFU);
    s_regs[REG_ADDR_VBAT_2R] = (uint8_t)(vbat >> 8U);
}

uint8_t I2CSlave_GetODO1_Byte(uint8_t byteIndex)
{
    if (byteIndex > 3U) { return 0U; }
    return s_regs[REG_ADDR_ODO1_1R + byteIndex];
}

void I2CSlave_SetODO1(uint32_t odo)
{
    s_regs[REG_ADDR_ODO1_1R] = (uint8_t)(odo & 0xFFU);
    s_regs[REG_ADDR_ODO1_2R] = (uint8_t)((odo >> 8U)  & 0xFFU);
    s_regs[REG_ADDR_ODO1_3R] = (uint8_t)((odo >> 16U) & 0xFFU);
    s_regs[REG_ADDR_ODO1_4R] = (uint8_t)((odo >> 24U) & 0xFFU);
}

uint8_t I2CSlave_GetODO2_Byte(uint8_t byteIndex)
{
    if (byteIndex > 3U) { return 0U; }
    return s_regs[REG_ADDR_ODO2_1R + byteIndex];
}

void I2CSlave_SetODO2(uint32_t odo)
{
    s_regs[REG_ADDR_ODO2_1R] = (uint8_t)(odo & 0xFFU);
    s_regs[REG_ADDR_ODO2_2R] = (uint8_t)((odo >> 8U)  & 0xFFU);
    s_regs[REG_ADDR_ODO2_3R] = (uint8_t)((odo >> 16U) & 0xFFU);
    s_regs[REG_ADDR_ODO2_4R] = (uint8_t)((odo >> 24U) & 0xFFU);
}

uint16_t I2CSlave_GetMOT1(void)
{
    return (uint16_t)s_regs[REG_ADDR_MOT1_1R] |
           ((uint16_t)s_regs[REG_ADDR_MOT1_2R] << 8U);
}

void I2CSlave_SetMOT1(uint16_t value)
{
    s_regs[REG_ADDR_MOT1_1R] = (uint8_t)(value & 0xFFU);
    s_regs[REG_ADDR_MOT1_2R] = (uint8_t)(value >> 8U);
}

uint16_t I2CSlave_GetMOT2(void)
{
    return (uint16_t)s_regs[REG_ADDR_MOT2_1R] |
           ((uint16_t)s_regs[REG_ADDR_MOT2_2R] << 8U);
}

void I2CSlave_SetMOT2(uint16_t value)
{
    s_regs[REG_ADDR_MOT2_1R] = (uint8_t)(value & 0xFFU);
    s_regs[REG_ADDR_MOT2_2R] = (uint8_t)(value >> 8U);
}

uint16_t I2CSlave_GetDIR(void)
{
    return (uint16_t)s_regs[REG_ADDR_DIR_1R] |
           ((uint16_t)s_regs[REG_ADDR_DIR_2R] << 8U);
}

void I2CSlave_SetDIR(uint16_t value)
{
    s_regs[REG_ADDR_DIR_1R] = (uint8_t)(value & 0xFFU);
    s_regs[REG_ADDR_DIR_2R] = (uint8_t)(value >> 8U);
}

uint8_t I2CSlave_GetCR(void)
{
    return s_regs[REG_ADDR_CR];
}

void I2CSlave_SetCR(uint8_t value)
{
    s_regs[REG_ADDR_CR] = value;
}
